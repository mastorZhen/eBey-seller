Preinstall Device Driver
RemoteWakeup Not Support
Win7 A2DP_SNK 
Win8 A2DP_SRC  A2DP_SNK  
Win8.1 A2DP_SRC  A2DP_SNK

Support 8723A, 8723B, 8821A, 8761A 